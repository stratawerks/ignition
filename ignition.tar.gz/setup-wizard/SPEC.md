# StrataOS Control Panel — Technical Specification
_v2.0 — 2026-05-07_

## Concept

Two modes, one app, one port (18792):

1. **Wizard mode** — shown on first boot when not configured. Two screens only: bot token + model. Done in under 2 minutes.
2. **Dashboard mode** — shown after setup. Persistent management console. "Single pane of glass." Comes alive when the agent does.

The wizard is the on-ramp. The dashboard is where the user lives.

---

## Wizard (Mode 1 — First Boot)

### Screen 1: Connect Your Bot
```
╔══════════════════════════════════════════════╗
║  StrataOS                                    ║
║  ─────────────────────────────────────────   ║
║  Let's connect your agent.                   ║
║                                              ║
║  Step 1: Open Telegram → search @BotFather   ║
║  Step 2: Send /newbot and follow prompts     ║
║  Step 3: Paste your bot token below          ║
║                                              ║
║  Bot Token: [_____________________________]  ║
║                                              ║
║  [How do I do this?]  [Continue →]           ║
╚══════════════════════════════════════════════╝
```

### Screen 2: Choose Your AI
```
╔══════════════════════════════════════════════╗
║  StrataOS                                    ║
║  ─────────────────────────────────────────   ║
║  Choose your AI provider.                    ║
║                                              ║
║  [OpenRouter ★]  [OpenAI]  [Anthropic]       ║
║   (recommended)                              ║
║                                              ║
║  API Key: [_______________________________]  ║
║  [Get a free key at openrouter.ai]           ║
║                                              ║
║  [← Back]                    [Launch →]      ║
╚══════════════════════════════════════════════╝
```

"Launch" button:
- Saves config
- Restarts gateway
- Shows spinner: "Starting your agent..."
- On success: transitions to Dashboard mode
- Agent sends welcome message to user via Telegram

---

## Dashboard (Mode 2 — Persistent)

Always accessible at http://<box-ip>:18792

```
╔═══════════════════════════════════════════════════════════╗
║  StrataOS Control Panel                   v2026.4.25      ║
╠═══════════════════════════════════════════════════════════╣
║                                                           ║
║  ● AGENT ONLINE   main · @MyBot                          ║
║  Last active: 2 minutes ago      [■ Restart Gateway]     ║
║                                                           ║
╠══════════════════╦════════════════╦═══════════════════════╣
║  MANAGE          ║  LICENSE       ║  CHAT WITH YOUR AGENT ║
║                  ║                ║                       ║
║  [→ Dashboard]   ║  Personal      ║  Your agent is ready  ║
║  [→ Terminal]    ║  1 of 1 seats  ║  to help. Open        ║
║  [→ Telegram]    ║  Active        ║  Telegram and send    ║
║                  ║  [Renew / ↑]   ║  it a message.        ║
║                  ║                ║                       ║
║                  ║                ║  [Open Telegram →]    ║
╚══════════════════╩════════════════╩═══════════════════════╝
```

### Dashboard Elements

| Element | Behavior |
|---|---|
| **Agent status** | Green dot = online, Red = offline. Polls /health every 15s. |
| **Last active** | Timestamp of last agent message processed. |
| **Restart Gateway** | POST to /api/restart → runs `systemctl --user restart openclaw-gateway` → waits for /health → updates status. |
| **Dashboard link** | Opens :18789 in new tab. |
| **Terminal link** | Opens :18790 in new tab. |
| **Telegram link** | Deep link to the bot (`https://t.me/<botname>`). |
| **License panel** | Shows tier, seat count, expiry. Powered by Keygen.sh API (or static config for v1). |
| **Renew/Upgrade** | Links to stratawerks.ai/account. |
| **Open Telegram** | Primary CTA — this is where the agent-led experience lives. |

### Agent Tour (Telegram-side)

When the agent first comes online, it sends a welcome message:

> "👋 Hi! I'm your StrataOS agent. I'm running on your hardware — your data never leaves your network.
>
> Here's what I can do: [brief list]
>
> Say **help** anytime to see what I can do, or just ask me anything."

The dashboard's "Chat with your agent" section explains this — the tour happens in Telegram, not the web UI. Web UI is management only.

---

## Technical Architecture

```
Browser → http://<box-ip>:18792
                │
         Flask app (always running)
                │
         ┌──────┴──────┐
         │             │
    Not configured   Configured
         │             │
      Wizard         Dashboard
    (2 screens)    (management UI)
         │             │
         └──────┬──────┘
                │
        ConfigManager (openclaw.json, .env)
        GatewayController (systemctl)
        StatusPoller (/health every 15s)
        LicenseClient (Keygen.sh API — v2)
```

## File Structure

```
projects/cornerstone/setup-wizard/
├── SPEC.md
├── app/
│   ├── __init__.py
│   ├── main.py               # Flask app, routing, mode detection
│   ├── config_manager.py     # openclaw.json / .env read-write (unchanged)
│   ├── provider_tester.py    # API key validation (unchanged)
│   ├── telegram_tester.py    # Bot token validation (unchanged)
│   ├── gateway_controller.py # Gateway restart/status (unchanged)
│   ├── static/
│   │   ├── style.css         # Shared styles — wizard + dashboard
│   │   └── app.js            # Status polling, restart button, transitions
│   └── templates/
│       ├── base.html         # Minimal layout shell
│       ├── wizard_bot.html   # Wizard screen 1: bot token
│       ├── wizard_model.html # Wizard screen 2: model/API key
│       ├── launching.html    # Spinner screen during gateway restart
│       └── dashboard.html    # Persistent management console
```

## Routes

| Method | Path | Purpose |
|---|---|---|
| GET | / | Redirect: wizard or dashboard |
| GET | /setup | Wizard screen 1 (bot token) |
| POST | /setup | Save bot token, go to screen 2 |
| GET | /setup/model | Wizard screen 2 (model/API key) |
| POST | /setup/model | Save config, restart gateway, go to launching |
| GET | /launching | Spinner — polls until gateway is up |
| GET | /dashboard | Management console |
| POST | /api/restart | Restart gateway (returns JSON) |
| GET | /api/status | Gateway health + setup status (JSON) |
| POST | /api/test-provider | Test API key (JSON) |
| POST | /api/test-telegram | Test bot token (JSON) |
| POST | /api/reset | Reset to wizard (requires confirmation) |

## Bug Workarounds (unchanged from v1)

| Bug | Workaround |
|---|---|
| BUG-009 | Wizard runs locally — no device pairing needed |
| BUG-011 | HTTP only (no openssl in nix-shell); `dangerouslyDisableDeviceAuth: true` |
| BUG-012 | Never runs `openclaw onboard`; always writes bind `0.0.0.0` directly |

## Success Criteria

- Setup completes in under 2 minutes (down from 5 in v1)
- Dashboard loads in under 1 second
- Gateway status updates without page refresh
- Restart button works and shows result in-page
- Non-technical user understands every element on screen
- Mobile responsive
