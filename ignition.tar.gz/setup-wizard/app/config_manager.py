"""
Config Manager — safe read/write of ~/.openclaw/openclaw.json and ~/.openclaw/.env.

Responsibilities:
  • Load existing config, preserving unknown keys
  • Deep-merge wizard values into the config tree
  • Validate JSON before writing
  • Create timestamped backup before every write
  • File-level locking to prevent concurrent corruption
  • Manage .env file for API keys (never stored in JSON)
"""

from __future__ import annotations

import copy
import fcntl
import json
import logging
import os
import shutil
import stat
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

OPENCLAW_DIR = Path.home() / ".openclaw"
CONFIG_PATH = OPENCLAW_DIR / "openclaw.json"
ENV_PATH = OPENCLAW_DIR / ".env"
BACKUP_DIR = OPENCLAW_DIR / "backups"


def _deep_merge(base: dict, overlay: dict) -> dict:
    """Recursively merge *overlay* into *base* (mutates base)."""
    for key, value in overlay.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value
    return base


class ConfigManager:
    """Thread-safe manager for OpenClaw configuration files."""

    def __init__(self, config_path: Path | None = None, env_path: Path | None = None):
        self.config_path = config_path or CONFIG_PATH
        self.env_path = env_path or ENV_PATH
        self.config_path.parent.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # openclaw.json
    # ------------------------------------------------------------------

    def load(self) -> dict[str, Any]:
        """Load and return the current config, or an empty dict if missing."""
        if not self.config_path.exists():
            log.info("No config file found at %s — starting fresh", self.config_path)
            return {}
        try:
            with open(self.config_path, "r") as f:
                fcntl.flock(f, fcntl.LOCK_SH)
                data = json.load(f)
                fcntl.flock(f, fcntl.LOCK_UN)
            return data
        except (json.JSONDecodeError, OSError) as exc:
            log.error("Failed to read config: %s", exc)
            raise ConfigError(f"Could not read configuration file: {exc}") from exc

    def save(self, config: dict[str, Any]) -> None:
        """Write *config* to disk with backup and locking."""
        # Validate serialisability before touching anything
        try:
            payload = json.dumps(config, indent=2, ensure_ascii=False)
        except (TypeError, ValueError) as exc:
            raise ConfigError(f"Invalid configuration data: {exc}") from exc

        self._backup()

        tmp_path = self.config_path.with_suffix(".tmp")
        try:
            with open(tmp_path, "w") as f:
                fcntl.flock(f, fcntl.LOCK_EX)
                f.write(payload + "\n")
                f.flush()
                os.fsync(f.fileno())
                fcntl.flock(f, fcntl.LOCK_UN)
            tmp_path.replace(self.config_path)
            log.info("Config saved to %s", self.config_path)
        except OSError as exc:
            tmp_path.unlink(missing_ok=True)
            raise ConfigError(f"Failed to write config: {exc}") from exc

    def merge_and_save(self, overlay: dict[str, Any]) -> dict[str, Any]:
        """Load current config, deep-merge *overlay*, save, and return result."""
        current = self.load()
        merged = _deep_merge(current, overlay)
        self.save(merged)
        return merged

    def _backup(self) -> None:
        """Create a timestamped backup of the current config if it exists."""
        if not self.config_path.exists():
            return
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        dest = BACKUP_DIR / f"openclaw.json.{ts}.bak"
        try:
            shutil.copy2(self.config_path, dest)
            log.info("Backup created: %s", dest)
        except OSError as exc:
            log.warning("Backup failed (continuing anyway): %s", exc)

    # ------------------------------------------------------------------
    # .env  (API keys)
    # ------------------------------------------------------------------

    def load_env(self) -> dict[str, str]:
        """Parse the .env file into a dict."""
        env: dict[str, str] = {}
        if not self.env_path.exists():
            return env
        with open(self.env_path, "r") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    key, _, value = line.partition("=")
                    env[key.strip()] = value.strip().strip("\"'")
        return env

    def save_env(self, env: dict[str, str]) -> None:
        """Write the .env file with restricted permissions (0600)."""
        lines = [f'{k}="{v}"' for k, v in sorted(env.items())]
        content = "\n".join(lines) + "\n"

        tmp_path = self.env_path.with_suffix(".tmp")
        try:
            with open(tmp_path, "w") as f:
                f.write(content)
                f.flush()
                os.fsync(f.fileno())
            os.chmod(tmp_path, stat.S_IRUSR | stat.S_IWUSR)  # 0600
            tmp_path.replace(self.env_path)
            log.info(".env saved to %s", self.env_path)
        except OSError as exc:
            tmp_path.unlink(missing_ok=True)
            raise ConfigError(f"Failed to write .env: {exc}") from exc

    def set_env_var(self, key: str, value: str) -> None:
        """Set a single environment variable in the .env file."""
        env = self.load_env()
        env[key] = value
        self.save_env(env)

    # ------------------------------------------------------------------
    # Status helpers
    # ------------------------------------------------------------------

    def is_setup_complete(self) -> bool:
        """Check whether minimal setup has been completed."""
        config = self.load()
        env = self.load_env()

        has_provider = bool(
            env.get("OPENAI_API_KEY")
            or env.get("ANTHROPIC_API_KEY")
            or env.get("OPENROUTER_API_KEY")
        )
        has_telegram = bool(
            config.get("channels", {}).get("telegram", {}).get("botToken")
        )
        return has_provider and has_telegram

    def get_setup_status(self) -> dict[str, Any]:
        """Return a summary of what's configured."""
        config = self.load()
        env = self.load_env()

        provider = None
        if env.get("OPENAI_API_KEY"):
            provider = "openai"
        elif env.get("ANTHROPIC_API_KEY"):
            provider = "anthropic"
        elif env.get("OPENROUTER_API_KEY"):
            provider = "openrouter"

        telegram = config.get("channels", {}).get("telegram", {})

        return {
            "provider": provider,
            "has_api_key": provider is not None,
            "telegram_configured": bool(telegram.get("botToken")),
            "telegram_user_id": telegram.get("allowedUsers", [None])[0],
            "setup_complete": provider is not None and bool(telegram.get("botToken")),
        }


class ConfigError(Exception):
    """Raised when config read/write fails."""
