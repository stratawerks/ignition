"""
StrataOS Control Panel v2 — Flask application.

Two modes:
  - Wizard: first-boot setup (bot token + model, 2 screens)
  - Dashboard: persistent management console (post-setup)

Run: python -m app.main
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path

from flask import Flask, jsonify, redirect, render_template, request, url_for

from . import __version__
from .config_manager import ConfigError, ConfigManager
from .gateway_controller import get_status as gw_status
from .gateway_controller import restart as gw_restart
from .provider_tester import PROVIDER_META, get_default_model, get_env_var_name, test_provider
from .telegram_tester import (
    build_telegram_config,
    test_bot_token,
    validate_token_format,
    validate_user_id,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
log = logging.getLogger(__name__)


def create_app() -> Flask:
    app = Flask(
        __name__,
        static_folder="static",
        template_folder="templates",
    )
    app.secret_key = os.urandom(32)
    cm = ConfigManager()

    @app.context_processor
    def inject_globals():
        return {"version": __version__}

    # ------------------------------------------------------------------
    # Root — mode detection
    # ------------------------------------------------------------------

    @app.route("/")
    def index():
        status = cm.get_setup_status()
        if status.get("complete"):
            return redirect(url_for("dashboard"))
        return redirect(url_for("wizard_bot"))

    # ------------------------------------------------------------------
    # Wizard — Screen 1: Bot Token
    # ------------------------------------------------------------------

    @app.route("/setup", methods=["GET"])
    def wizard_bot():
        return render_template("wizard_bot.html")

    @app.route("/setup", methods=["POST"])
    def wizard_bot_post():
        bot_token = request.form.get("bot_token", "").strip()
        user_id = request.form.get("user_id", "").strip()

        errors = []
        token_err = validate_token_format(bot_token)
        if token_err:
            errors.append(token_err)
        uid_err = validate_user_id(user_id)
        if uid_err:
            errors.append(uid_err)

        if errors:
            return render_template("wizard_bot.html", errors=errors,
                                   bot_token=bot_token, user_id=user_id)

        result = test_bot_token(bot_token)
        if not result.success:
            return render_template("wizard_bot.html",
                                   errors=[result.error],
                                   bot_token=bot_token, user_id=user_id)

        # Store temporarily in session-like hidden fields via next page
        return render_template("wizard_model.html",
                                bot_token=bot_token,
                                user_id=user_id,
                                bot_username=result.bot_username)

    # ------------------------------------------------------------------
    # Wizard — Screen 2: Model / API Key
    # ------------------------------------------------------------------

    @app.route("/setup/model", methods=["POST"])
    def wizard_model_post():
        bot_token = request.form.get("bot_token", "").strip()
        user_id = request.form.get("user_id", "").strip()
        bot_username = request.form.get("bot_username", "").strip()
        provider = request.form.get("provider", "openrouter").strip().lower()
        api_key = request.form.get("api_key", "").strip()

        errors = []
        if provider not in PROVIDER_META:
            errors.append("Please select a valid AI provider.")
        if not api_key:
            errors.append("API key is required.")

        if errors:
            return render_template("wizard_model.html",
                                   errors=errors,
                                   bot_token=bot_token,
                                   user_id=user_id,
                                   bot_username=bot_username,
                                   selected_provider=provider)

        result = test_provider(provider, api_key)
        if not result.success:
            return render_template("wizard_model.html",
                                   errors=[result.error],
                                   bot_token=bot_token,
                                   user_id=user_id,
                                   bot_username=bot_username,
                                   selected_provider=provider)

        # Save API key to .env
        env_var = get_env_var_name(provider)
        env = cm.load_env()
        for meta in PROVIDER_META.values():
            env.pop(meta["env_var"], None)
        env[env_var] = api_key
        cm.save_env(env)

        # Write openclaw.json
        default_model = get_default_model(provider)
        telegram_cfg = build_telegram_config(bot_token, user_id)
        try:
            cm.merge_and_save({
                "defaultModel": default_model,
                "gateway": {"listenAddress": "0.0.0.0"},
                **telegram_cfg,
            })
        except ConfigError as exc:
            return render_template("wizard_model.html",
                                   errors=[str(exc)],
                                   bot_token=bot_token,
                                   user_id=user_id,
                                   bot_username=bot_username,
                                   selected_provider=provider)

        # Restart gateway
        gw_restart()
        time.sleep(2)

        # Re-save telegram config (BUG-012: gateway may overwrite on restart)
        try:
            cm.merge_and_save(telegram_cfg)
        except ConfigError:
            pass

        gw_restart()

        return redirect(url_for("launching"))

    # ------------------------------------------------------------------
    # Launching — spinner while gateway comes up
    # ------------------------------------------------------------------

    @app.route("/launching")
    def launching():
        return render_template("launching.html")

    # ------------------------------------------------------------------
    # Dashboard — persistent management console
    # ------------------------------------------------------------------

    @app.route("/dashboard")
    def dashboard():
        config = cm.load()
        bot_token = config.get("channels", {}).get("telegram", {}).get("botToken", "")
        bot_username = ""
        if bot_token:
            try:
                r = test_bot_token(bot_token)
                bot_username = r.bot_username or ""
            except Exception:
                pass

        gw = gw_status()

        return render_template("dashboard.html",
                                gateway=gw.to_dict(),
                                bot_username=bot_username,
                                version=__version__)

    # ------------------------------------------------------------------
    # API endpoints (JSON)
    # ------------------------------------------------------------------

    @app.route("/api/status")
    def api_status():
        status = cm.get_setup_status()
        gw = gw_status()
        return jsonify({
            "setup": status,
            "gateway": gw.to_dict(),
        })

    @app.route("/api/restart", methods=["POST"])
    def api_restart():
        result = gw_restart()
        time.sleep(3)
        gw = gw_status()
        return jsonify({
            "success": not result.error,
            "error": result.error,
            "gateway": gw.to_dict(),
        })

    @app.route("/api/test-provider", methods=["POST"])
    def api_test_provider():
        data = request.get_json(silent=True) or {}
        provider = data.get("provider", "").strip().lower()
        api_key = data.get("api_key", "").strip()
        if provider not in PROVIDER_META:
            return jsonify({"success": False, "error": "Unknown provider."}), 400
        if not api_key:
            return jsonify({"success": False, "error": "API key is required."}), 400
        result = test_provider(provider, api_key)
        return jsonify(result.to_dict())

    @app.route("/api/test-telegram", methods=["POST"])
    def api_test_telegram():
        data = request.get_json(silent=True) or {}
        token = data.get("bot_token", "").strip()
        result = test_bot_token(token)
        return jsonify(result.to_dict())

    @app.route("/api/reset", methods=["POST"])
    def api_reset():
        """Reset to wizard mode (clears setup state)."""
        try:
            cm.merge_and_save({
                "channels": {"telegram": {"enabled": False, "botToken": ""}},
                "defaultModel": "",
            })
            env = cm.load_env()
            for meta in PROVIDER_META.values():
                env.pop(meta["env_var"], None)
            cm.save_env(env)
            return jsonify({"success": True})
        except Exception as exc:
            return jsonify({"success": False, "error": str(exc)})

    return app


def main():
    port = int(os.environ.get("WIZARD_PORT", "18792"))
    host = os.environ.get("WIZARD_HOST", "0.0.0.0")
    app = create_app()
    log.info("Starting StrataOS Control Panel on http://%s:%d", host, port)
    app.run(host=host, port=port, debug=False)


if __name__ == "__main__":
    main()
