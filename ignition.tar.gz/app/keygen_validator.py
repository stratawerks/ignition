"""
Keygen.sh license validation for Ignition wizard.

Uses the public license validation endpoint — no admin token required on device.
The KEYGEN_ACCOUNT_ID is baked into the Ignition package at build time.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

import requests

KEYGEN_ACCOUNT_ID = os.environ.get(
    "KEYGEN_ACCOUNT_ID", "59ab7b61-2259-462a-a2db-edfdcd2eb779"
)
KEYGEN_API_BASE = "https://api.keygen.sh/v1/accounts"

# Product token — read-only, safe to ship in binary
# This token can only validate licenses, not create or modify anything.
KEYGEN_PRODUCT_TOKEN = os.environ.get(
    "KEYGEN_PRODUCT_TOKEN", ""  # set via env or injected at build
)


@dataclass
class LicenseResult:
    valid: bool
    seats: int
    key: str
    name: str
    expiry: str | None
    detail: str
    code: str
    error: str | None = None

    def to_dict(self) -> dict:
        return {
            "valid": self.valid,
            "seats": self.seats,
            "key": self.key,
            "name": self.name,
            "expiry": self.expiry,
            "detail": self.detail,
            "code": self.code,
            "error": self.error,
        }


def validate_license(key: str) -> LicenseResult:
    """
    Validate a license key against Keygen.sh.
    Returns a LicenseResult with seat count and validity.
    """
    key = key.strip().upper()
    if not key:
        return LicenseResult(
            valid=False, seats=0, key=key, name="", expiry=None,
            detail="License key is required.", code="KEY_MISSING",
            error="Please enter your license key."
        )

    url = f"{KEYGEN_API_BASE}/{KEYGEN_ACCOUNT_ID}/licenses/actions/validate-key"

    headers = {
        "Content-Type": "application/vnd.api+json",
        "Accept": "application/vnd.api+json",
    }
    if KEYGEN_PRODUCT_TOKEN:
        headers["Authorization"] = f"Bearer {KEYGEN_PRODUCT_TOKEN}"

    payload = {"meta": {"key": key}}

    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=10)
    except requests.RequestException as exc:
        return LicenseResult(
            valid=False, seats=0, key=key, name="", expiry=None,
            detail="Could not reach license server.", code="NETWORK_ERROR",
            error=f"Network error: {exc}"
        )

    data = resp.json()
    meta = data.get("meta", {})
    license_data = data.get("data") or {}
    attrs = license_data.get("attributes", {}) if license_data else {}

    code = meta.get("code", "UNKNOWN")
    detail = meta.get("detail", "Unknown response from license server.")
    valid = meta.get("valid", False)

    seats = attrs.get("maxMachines", 1) or 1
    name = attrs.get("name", "")
    expiry = attrs.get("expiry")

    if not valid:
        human_errors = {
            "NOT_FOUND": "License key not found. Please check and try again.",
            "SUSPENDED": "This license has been suspended. Contact support.",
            "EXPIRED": "This license has expired. Please renew at stratawerks.ai.",
            "OVERDUE": "License validation is overdue. Please contact support.",
            "NO_MACHINE": "License requires machine activation.",
            "FINGERPRINT_SCOPE_MISMATCH": "This license is already activated on another machine.",
        }
        error = human_errors.get(code, f"License invalid: {detail}")
        return LicenseResult(
            valid=False, seats=0, key=key, name=name, expiry=expiry,
            detail=detail, code=code, error=error
        )

    return LicenseResult(
        valid=True, seats=seats, key=key, name=name, expiry=expiry,
        detail=detail, code=code
    )
