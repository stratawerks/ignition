"""
Provider Tester — validate AI provider API keys with real API calls.

Supported providers:
  • OpenAI      — GET /v1/models
  • Anthropic   — POST /v1/messages (minimal payload)
  • OpenRouter  — GET /api/v1/models
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

import requests

log = logging.getLogger(__name__)

REQUEST_TIMEOUT = 15  # seconds


@dataclass
class TestResult:
    success: bool
    provider: str
    model: str | None = None
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "provider": self.provider,
            "model": self.model,
            "error": self.error,
        }


# -- Provider env-var and default model mappings --

PROVIDER_META: dict[str, dict[str, str]] = {
    "openai": {
        "env_var": "OPENAI_API_KEY",
        "default_model": "openai/gpt-4o",
        "display_model": "gpt-4o",
    },
    "anthropic": {
        "env_var": "ANTHROPIC_API_KEY",
        "default_model": "anthropic/claude-sonnet-4-20250514",
        "display_model": "claude-sonnet-4-20250514",
    },
    "openrouter": {
        "env_var": "OPENROUTER_API_KEY",
        "default_model": "openrouter/auto",
        "display_model": "auto (best available)",
    },
}


def test_provider(provider: str, api_key: str) -> TestResult:
    """Validate an API key for the given provider.  Returns a TestResult."""
    provider = provider.lower().strip()
    if provider not in PROVIDER_META:
        return TestResult(
            success=False,
            provider=provider,
            error=f"Unknown provider: {provider}",
        )

    if not api_key or not api_key.strip():
        return TestResult(
            success=False,
            provider=provider,
            error="API key is required.",
        )

    api_key = api_key.strip()

    testers = {
        "openai": _test_openai,
        "anthropic": _test_anthropic,
        "openrouter": _test_openrouter,
    }

    try:
        return testers[provider](api_key)
    except requests.Timeout:
        return TestResult(
            success=False,
            provider=provider,
            error="Connection timed out. Please check your network and try again.",
        )
    except requests.ConnectionError:
        return TestResult(
            success=False,
            provider=provider,
            error="Could not connect to the provider. Please check your network.",
        )
    except Exception as exc:
        log.exception("Unexpected error testing %s", provider)
        return TestResult(
            success=False,
            provider=provider,
            error=f"Unexpected error: {exc}",
        )


def _test_openai(api_key: str) -> TestResult:
    resp = requests.get(
        "https://api.openai.com/v1/models",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=REQUEST_TIMEOUT,
    )
    if resp.status_code == 401:
        return TestResult(False, "openai", error="Invalid API key.")
    if resp.status_code == 429:
        return TestResult(False, "openai", error="Rate limited — key is valid but hit quota. Try again shortly.")
    resp.raise_for_status()

    models = resp.json().get("data", [])
    model_ids = [m["id"] for m in models]
    # Pick best available model to display
    preferred = ["gpt-4o", "gpt-4-turbo", "gpt-4", "gpt-3.5-turbo"]
    display = next((m for m in preferred if m in model_ids), model_ids[0] if model_ids else "gpt-4o")

    return TestResult(True, "openai", model=display)


def _test_anthropic(api_key: str) -> TestResult:
    resp = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        json={
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 1,
            "messages": [{"role": "user", "content": "hi"}],
        },
        timeout=REQUEST_TIMEOUT,
    )
    if resp.status_code == 401:
        return TestResult(False, "anthropic", error="Invalid API key.")
    if resp.status_code == 429:
        return TestResult(False, "anthropic", error="Rate limited — key is valid but hit quota.")
    # 200 or 400 (bad request but auth passed) both mean the key works
    if resp.status_code in (200, 400):
        return TestResult(True, "anthropic", model="claude-sonnet-4-20250514")
    resp.raise_for_status()
    return TestResult(True, "anthropic", model="claude-sonnet-4-20250514")


def _test_openrouter(api_key: str) -> TestResult:
    resp = requests.get(
        "https://openrouter.ai/api/v1/models",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=REQUEST_TIMEOUT,
    )
    if resp.status_code == 401:
        return TestResult(False, "openrouter", error="Invalid API key.")
    if resp.status_code == 429:
        return TestResult(False, "openrouter", error="Rate limited — try again shortly.")
    resp.raise_for_status()
    return TestResult(True, "openrouter", model="auto (best available)")


def get_env_var_name(provider: str) -> str:
    """Return the environment variable name for a provider's API key."""
    meta = PROVIDER_META.get(provider.lower())
    if not meta:
        raise ValueError(f"Unknown provider: {provider}")
    return meta["env_var"]


def get_default_model(provider: str) -> str:
    """Return the default model string for openclaw.json."""
    meta = PROVIDER_META.get(provider.lower())
    if not meta:
        raise ValueError(f"Unknown provider: {provider}")
    return meta["default_model"]
