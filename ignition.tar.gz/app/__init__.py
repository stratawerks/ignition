"""StrataOS Setup Wizard — guided first-time OpenClaw configuration."""

__version__ = "1.0.0"
