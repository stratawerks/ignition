"""
Gateway Controller — restart and health-check the OpenClaw gateway.

Uses subprocess to call `openclaw gateway restart` and `openclaw gateway status`.
"""

from __future__ import annotations

import logging
import subprocess
import time
from dataclasses import dataclass
from typing import Any

log = logging.getLogger(__name__)

RESTART_CMD = ["openclaw", "gateway", "restart"]
STATUS_CMD = ["openclaw", "gateway", "status"]
SUBPROCESS_TIMEOUT = 30  # seconds per command
HEALTH_POLL_INTERVAL = 2  # seconds between status checks
HEALTH_MAX_WAIT = 60  # max seconds to wait for ready


@dataclass
class GatewayStatus:
    running: bool
    ready: bool
    detail: str | None = None
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "running": self.running,
            "ready": self.ready,
            "detail": self.detail,
            "error": self.error,
        }


def get_status() -> GatewayStatus:
    """Check the current gateway status."""
    try:
        result = subprocess.run(
            STATUS_CMD,
            capture_output=True,
            text=True,
            timeout=SUBPROCESS_TIMEOUT,
        )
        output = (result.stdout + result.stderr).strip()
        log.debug("Gateway status output: %s", output)

        # Parse output for status indicators
        output_lower = output.lower()
        running = result.returncode == 0 or "running" in output_lower
        ready = "ready" in output_lower or "rpc" in output_lower

        return GatewayStatus(
            running=running,
            ready=ready,
            detail=output,
        )
    except subprocess.TimeoutExpired:
        return GatewayStatus(
            running=False,
            ready=False,
            error="Gateway status check timed out.",
        )
    except FileNotFoundError:
        return GatewayStatus(
            running=False,
            ready=False,
            error="OpenClaw CLI not found. Is it installed?",
        )
    except OSError as exc:
        return GatewayStatus(
            running=False,
            ready=False,
            error=f"Could not check gateway status: {exc}",
        )


def restart() -> GatewayStatus:
    """Restart the gateway and return its status."""
    log.info("Restarting OpenClaw gateway...")
    try:
        result = subprocess.run(
            RESTART_CMD,
            capture_output=True,
            text=True,
            timeout=SUBPROCESS_TIMEOUT,
        )
        output = (result.stdout + result.stderr).strip()
        log.info("Restart output: %s", output)

        if result.returncode != 0:
            return GatewayStatus(
                running=False,
                ready=False,
                error=f"Gateway restart failed: {output}",
            )
    except subprocess.TimeoutExpired:
        return GatewayStatus(
            running=False,
            ready=False,
            error="Gateway restart timed out.",
        )
    except FileNotFoundError:
        return GatewayStatus(
            running=False,
            ready=False,
            error="OpenClaw CLI not found. Is it installed?",
        )
    except OSError as exc:
        return GatewayStatus(
            running=False,
            ready=False,
            error=f"Could not restart gateway: {exc}",
        )

    # Poll for readiness
    return wait_for_ready()


def wait_for_ready(max_wait: int = HEALTH_MAX_WAIT) -> GatewayStatus:
    """Poll gateway status until it reports ready or timeout."""
    start = time.monotonic()
    last_status = None

    while time.monotonic() - start < max_wait:
        last_status = get_status()
        if last_status.ready:
            log.info("Gateway is ready.")
            return last_status
        if last_status.error:
            log.warning("Gateway error during wait: %s", last_status.error)
            return last_status
        time.sleep(HEALTH_POLL_INTERVAL)

    # Timed out waiting
    return GatewayStatus(
        running=last_status.running if last_status else False,
        ready=False,
        error="Gateway did not become ready within the timeout period.",
        detail=last_status.detail if last_status else None,
    )
