"""
Seat Manager — multi-seat state management during the Ignition wizard.

Persists seat tokens to /tmp/ignition-seats-state.json between wizard screens.
Cleared after successful config write.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

STATE_FILE = Path("/tmp/ignition-seats-state.json")
OPENCLAW_BASE = Path.home() / ".openclaw"


def _load() -> dict:
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text())
        except Exception:
            pass
    return {"admin_user_id": "", "seats": []}


def _save(state: dict) -> None:
    STATE_FILE.write_text(json.dumps(state, indent=2))


def save_admin_user_id(user_id: str) -> None:
    state = _load()
    state["admin_user_id"] = user_id
    _save(state)


def get_admin_user_id() -> str:
    return _load().get("admin_user_id", "")


def save_seat(seat_num: int, token: str, bot_username: str) -> None:
    state = _load()
    seats = state.get("seats", [])
    for s in seats:
        if s["seat_num"] == seat_num:
            s["token"] = token
            s["bot_username"] = bot_username
            _save(state)
            return
    seats.append({
        "seat_num": seat_num,
        "token": token,
        "bot_username": bot_username,
    })
    state["seats"] = sorted(seats, key=lambda x: x["seat_num"])
    _save(state)


def get_seat(seat_num: int) -> dict | None:
    for s in _load().get("seats", []):
        if s["seat_num"] == seat_num:
            return s
    return None


def get_all_seats() -> list[dict]:
    return _load().get("seats", [])


def configured_seat_count() -> int:
    return len(_load().get("seats", []))


def clear() -> None:
    STATE_FILE.unlink(missing_ok=True)


def build_multi_agent_config(seats: list[dict], admin_user_id: str, default_model: str) -> dict:
    """
    Build the full openclaw.json overlay for a multi-seat installation.
    Each seat gets its own agent, telegram account, and binding.
    """
    workspace_base = OPENCLAW_BASE / "workspace" / "agents"

    agents_list = []
    telegram_accounts = {}
    bindings = []

    for i, seat in enumerate(seats):
        seat_id = f"seat{seat['seat_num']}"
        workspace = str(workspace_base / seat_id)

        # Create workspace directory
        Path(workspace).mkdir(parents=True, exist_ok=True)

        agents_list.append({
            "id": seat_id,
            "default": (i == 0),
            "workspace": workspace,
            "model": default_model,
        })

        telegram_accounts[seat_id] = {
            "name": seat_id,
            "botToken": seat["token"],
            "dmPolicy": "open",
            "allowFrom": ["*"],
        }

        bindings.append({
            "agentId": seat_id,
            "match": {
                "channel": "telegram",
                "accountId": seat_id,
            }
        })

    return {
        "agents": {
            "defaults": {
                "workspace": str(OPENCLAW_BASE / "workspace"),
                "compaction": {"mode": "safeguard"},
            },
            "list": agents_list,
        },
        "channels": {
            "telegram": {
                "enabled": True,
                **telegram_accounts,
            }
        },
        "bindings": bindings,
        "defaultModel": default_model,
        "gateway": {"listenAddress": "0.0.0.0"},
    }
