/* StrataOS Control Panel — v2 JS */
/* Status polling and restart logic are inline in dashboard.html */
/* This file is reserved for shared utilities */

// Smooth page transitions
document.addEventListener('DOMContentLoaded', function() {
  document.body.style.opacity = '0';
  document.body.style.transition = 'opacity 0.2s ease';
  requestAnimationFrame(function() {
    document.body.style.opacity = '1';
  });
});
