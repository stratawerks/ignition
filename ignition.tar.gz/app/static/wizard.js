/* =========================================================
   StrataOS Setup Wizard — Frontend JavaScript
   ========================================================= */

// ---------------------------------------------------------------------------
// Provider Page
// ---------------------------------------------------------------------------

function initProviderPage() {
    const radios = document.querySelectorAll('input[name="provider"]');
    const apiKeyGroup = document.getElementById('api-key-group');
    const helpSection = document.getElementById('help-section');
    const testSection = document.getElementById('test-section');
    const helpToggle = document.getElementById('help-toggle');
    const helpContent = document.getElementById('help-content');
    const testBtn = document.getElementById('test-connection');
    const testResult = document.getElementById('test-result');
    const toggleKeyBtn = document.getElementById('toggle-key-visibility');
    const apiKeyInput = document.getElementById('api_key');

    // Show/hide sections when provider is selected
    radios.forEach(radio => {
        radio.addEventListener('change', () => {
            apiKeyGroup.style.display = '';
            helpSection.style.display = '';
            testSection.style.display = '';
            testResult.style.display = 'none';
            testResult.className = 'test-result';

            // Update help content
            document.querySelectorAll('.help-provider').forEach(el => {
                el.style.display = 'none';
            });
            const selected = document.querySelector('input[name="provider"]:checked');
            if (selected) {
                const helpEl = document.getElementById('help-' + selected.value);
                if (helpEl) helpEl.style.display = '';
            }

            // Update provider card styles
            document.querySelectorAll('.provider-card').forEach(card => {
                card.classList.remove('selected');
            });
            radio.closest('.provider-card').classList.add('selected');

            // Update placeholder
            const placeholders = {
                openai: 'sk-...',
                anthropic: 'sk-ant-...',
                openrouter: 'sk-or-...'
            };
            if (apiKeyInput && selected) {
                apiKeyInput.placeholder = placeholders[selected.value] || 'Enter your API key';
            }
        });
    });

    // Help toggle
    if (helpToggle && helpContent) {
        helpToggle.addEventListener('click', () => {
            const visible = helpContent.style.display !== 'none';
            helpContent.style.display = visible ? 'none' : '';
            helpToggle.classList.toggle('open', !visible);
        });
    }

    // Toggle key visibility
    if (toggleKeyBtn && apiKeyInput) {
        toggleKeyBtn.addEventListener('click', () => {
            const isPassword = apiKeyInput.type === 'password';
            apiKeyInput.type = isPassword ? 'text' : 'password';
            toggleKeyBtn.textContent = isPassword ? 'Hide' : 'Show';
        });
    }

    // Test connection
    if (testBtn) {
        testBtn.addEventListener('click', async () => {
            const selected = document.querySelector('input[name="provider"]:checked');
            const key = apiKeyInput ? apiKeyInput.value.trim() : '';

            if (!selected) {
                showTestResult(testResult, false, 'Please select a provider.');
                return;
            }
            if (!key) {
                showTestResult(testResult, false, 'Please enter your API key.');
                return;
            }

            // Show spinner
            setButtonLoading(testBtn, true);
            testResult.style.display = 'none';

            try {
                const resp = await fetch('/api/test-provider', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        provider: selected.value,
                        api_key: key
                    })
                });

                const data = await resp.json();
                if (data.success) {
                    showTestResult(testResult, true,
                        '✅ Connected! Model: ' + (data.model || 'ready'));
                } else {
                    showTestResult(testResult, false,
                        '❌ ' + (data.error || 'Connection failed.'));
                }
            } catch (err) {
                showTestResult(testResult, false,
                    '❌ Network error. Please check your connection.');
            } finally {
                setButtonLoading(testBtn, false);
            }
        });
    }
}

// ---------------------------------------------------------------------------
// Messaging Page
// ---------------------------------------------------------------------------

function initMessagingPage() {
    // No separate verify button — Finish Setup does verify + save in one step
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function showTestResult(el, success, message) {
    if (!el) return;
    el.style.display = '';
    el.className = 'test-result ' + (success ? 'test-success' : 'test-error');
    el.textContent = message;
}

function setButtonLoading(btn, loading) {
    if (!btn) return;
    const text = btn.querySelector('.btn-text');
    const spinner = btn.querySelector('.btn-spinner');

    if (loading) {
        btn.disabled = true;
        if (text) text.style.display = 'none';
        if (spinner) spinner.style.display = '';
    } else {
        btn.disabled = false;
        if (text) text.style.display = '';
        if (spinner) spinner.style.display = 'none';
    }
}

// Auto-init based on page
document.addEventListener('DOMContentLoaded', () => {
    // Messaging page auto-init
    if (document.getElementById('test-telegram')) {
        initMessagingPage();
    }
});
