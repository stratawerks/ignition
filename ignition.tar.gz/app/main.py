"""
StrataOS Control Panel v2 — Flask application.

Two modes:
  - Wizard: first-boot setup (bot token + model, 2 screens)
  - Dashboard: persistent management console (post-setup)

Run: python -m app.main
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path

from flask import Flask, jsonify, redirect, render_template, request, url_for

from . import __version__
from .config_manager import ConfigError, ConfigManager
from .gateway_controller import get_status as gw_status
from .gateway_controller import restart as gw_restart
from .provider_tester import PROVIDER_META, get_default_model, get_env_var_name, test_provider
from .keygen_validator import validate_license
from .seat_manager import (
    build_multi_agent_config,
    clear as clear_seat_state,
    get_all_seats,
    save_admin_user_id,
    save_seat,
)
from .telegram_tester import (
    build_telegram_config,
    test_bot_token,
    validate_token_format,
    validate_user_id,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
log = logging.getLogger(__name__)


def create_app() -> Flask:
    app = Flask(
        __name__,
        static_folder="static",
        template_folder="templates",
    )
    app.secret_key = os.urandom(32)
    cm = ConfigManager()

    @app.context_processor
    def inject_globals():
        return {"version": __version__}

    # ------------------------------------------------------------------
    # Root — mode detection
    # ------------------------------------------------------------------

    @app.route("/")
    def index():
        status = cm.get_setup_status()
        if status.get("complete"):
            return redirect(url_for("dashboard"))
        # Check if license already validated this session
        if not cm.get_license_key():
            return redirect(url_for("wizard_license"))
        return redirect(url_for("wizard_bot"))

    # ------------------------------------------------------------------
    # Wizard — Screen 0: License Key
    # ------------------------------------------------------------------

    @app.route("/license", methods=["GET"])
    def wizard_license():
        return render_template("wizard_license.html")

    @app.route("/license", methods=["POST"])
    def wizard_license_post():
        key = request.form.get("license_key", "").strip()
        result = validate_license(key)
        if not result.valid:
            return render_template("wizard_license.html",
                                   errors=[result.error],
                                   license_key=key)
        # Store validated license in config
        cm.save_license(result.key, result.seats)
        clear_seat_state()
        if result.seats > 1:
            return redirect(url_for("wizard_seats_intro"))
        return redirect(url_for("wizard_bot"))

    @app.route("/api/validate-license", methods=["POST"])
    def api_validate_license():
        data = request.get_json(silent=True) or {}
        key = data.get("license_key", "").strip()
        result = validate_license(key)
        return jsonify(result.to_dict())

    # ------------------------------------------------------------------
    # Wizard — Multi-Seat: Seats Intro
    # ------------------------------------------------------------------

    @app.route("/setup/seats", methods=["GET"])
    def wizard_seats_intro():
        seats = cm.get_license_seats()
        return render_template("wizard_seats_intro.html", seats=seats)

    @app.route("/setup/seats", methods=["POST"])
    def wizard_seats_intro_post():
        user_id = request.form.get("user_id", "").strip()
        seats = cm.get_license_seats()
        uid_err = validate_user_id(user_id)
        if uid_err:
            return render_template("wizard_seats_intro.html", seats=seats,
                                   errors=[uid_err], user_id=user_id)
        save_admin_user_id(user_id)
        return redirect(url_for("wizard_seat", seat_num=1))

    # ------------------------------------------------------------------
    # Wizard — Multi-Seat: Per-Seat Bot Token
    # ------------------------------------------------------------------

    @app.route("/setup/seat/<int:seat_num>", methods=["GET"])
    def wizard_seat(seat_num):
        total = cm.get_license_seats()
        if seat_num < 1 or seat_num > total:
            return redirect(url_for("wizard_seats_intro"))
        return render_template("wizard_seat.html", seat_num=seat_num, total_seats=total)

    @app.route("/setup/seat/<int:seat_num>", methods=["POST"])
    def wizard_seat_post(seat_num):
        total = cm.get_license_seats()
        bot_token = request.form.get("bot_token", "").strip()

        errors = []
        token_err = validate_token_format(bot_token)
        if token_err:
            errors.append(token_err)

        if errors:
            return render_template("wizard_seat.html", seat_num=seat_num,
                                   total_seats=total, errors=errors,
                                   bot_token=bot_token)

        result = test_bot_token(bot_token)
        if not result.success:
            return render_template("wizard_seat.html", seat_num=seat_num,
                                   total_seats=total,
                                   errors=[result.error],
                                   bot_token=bot_token)

        save_seat(seat_num, bot_token, result.bot_username or "")

        if seat_num < total:
            return redirect(url_for("wizard_seat", seat_num=seat_num + 1))

        # All seats configured — go to model/provider screen
        return render_template("wizard_model.html",
                                mode="multi",
                                bot_token="",
                                user_id="",
                                bot_username=f"{total} seats configured")

    # ------------------------------------------------------------------
    # Wizard — Screen 1: Bot Token (single-seat)
    # ------------------------------------------------------------------

    @app.route("/setup", methods=["GET"])
    def wizard_bot():
        return render_template("wizard_bot.html")

    @app.route("/setup", methods=["POST"])
    def wizard_bot_post():
        bot_token = request.form.get("bot_token", "").strip()
        user_id = request.form.get("user_id", "").strip()

        errors = []
        token_err = validate_token_format(bot_token)
        if token_err:
            errors.append(token_err)
        uid_err = validate_user_id(user_id)
        if uid_err:
            errors.append(uid_err)

        if errors:
            return render_template("wizard_bot.html", errors=errors,
                                   bot_token=bot_token, user_id=user_id)

        result = test_bot_token(bot_token)
        if not result.success:
            return render_template("wizard_bot.html",
                                   errors=[result.error],
                                   bot_token=bot_token, user_id=user_id)

        # Store temporarily in session-like hidden fields via next page
        return render_template("wizard_model.html",
                                bot_token=bot_token,
                                user_id=user_id,
                                bot_username=result.bot_username)

    # ------------------------------------------------------------------
    # Wizard — Screen 2: Model / API Key
    # ------------------------------------------------------------------

    @app.route("/setup/model", methods=["POST"])
    def wizard_model_post():
        bot_token = request.form.get("bot_token", "").strip()
        user_id = request.form.get("user_id", "").strip()
        bot_username = request.form.get("bot_username", "").strip()
        provider = request.form.get("provider", "openrouter").strip().lower()
        api_key = request.form.get("api_key", "").strip()
        mode = request.form.get("mode", "single").strip()

        errors = []
        if provider not in PROVIDER_META:
            errors.append("Please select a valid AI provider.")
        if not api_key:
            errors.append("API key is required.")

        if errors:
            return render_template("wizard_model.html",
                                   errors=errors,
                                   bot_token=bot_token,
                                   user_id=user_id,
                                   bot_username=bot_username,
                                   selected_provider=provider)

        result = test_provider(provider, api_key)
        if not result.success:
            return render_template("wizard_model.html",
                                   errors=[result.error],
                                   bot_token=bot_token,
                                   user_id=user_id,
                                   bot_username=bot_username,
                                   selected_provider=provider)

        # Save API key to .env
        env_var = get_env_var_name(provider)
        env = cm.load_env()
        for meta in PROVIDER_META.values():
            env.pop(meta["env_var"], None)
        env[env_var] = api_key
        cm.save_env(env)

        default_model = get_default_model(provider)

        if mode == "multi":
            # Multi-seat: build config from seat state
            seats = get_all_seats()
            if not seats:
                return render_template("wizard_model.html",
                                       errors=["No seat data found. Please restart setup."],
                                       mode=mode,
                                       bot_token=bot_token,
                                       user_id=user_id,
                                       bot_username=bot_username,
                                       selected_provider=provider)
            config_overlay = build_multi_agent_config(seats, "", default_model)
            try:
                cm.merge_and_save(config_overlay)
            except ConfigError as exc:
                return render_template("wizard_model.html",
                                       errors=[str(exc)],
                                       mode=mode,
                                       bot_token=bot_token,
                                       user_id=user_id,
                                       bot_username=bot_username,
                                       selected_provider=provider)
            gw_restart()
            time.sleep(2)
            # BUG-012: re-save full multi-agent config after restart
            try:
                cm.merge_and_save({
                    "agents": config_overlay["agents"],
                    "channels": config_overlay["channels"],
                    "bindings": config_overlay["bindings"],
                })
            except ConfigError:
                pass
            gw_restart()
            clear_seat_state()
        else:
            # Single-seat: existing flow
            telegram_cfg = build_telegram_config(bot_token, user_id)
            try:
                cm.merge_and_save({
                    "defaultModel": default_model,
                    "gateway": {"listenAddress": "0.0.0.0"},
                    **telegram_cfg,
                })
            except ConfigError as exc:
                return render_template("wizard_model.html",
                                       errors=[str(exc)],
                                       bot_token=bot_token,
                                       user_id=user_id,
                                       bot_username=bot_username,
                                       selected_provider=provider)
            gw_restart()
            time.sleep(2)
            try:
                cm.merge_and_save(telegram_cfg)
            except ConfigError:
                pass
            gw_restart()

        return redirect(url_for("launching"))

    # ------------------------------------------------------------------
    # Launching — spinner while gateway comes up
    # ------------------------------------------------------------------

    @app.route("/launching")
    def launching():
        return render_template("launching.html")

    # ------------------------------------------------------------------
    # Dashboard — persistent management console
    # ------------------------------------------------------------------

    @app.route("/dashboard")
    def dashboard():
        config = cm.load()
        telegram = config.get("channels", {}).get("telegram", {})
        agents_list = config.get("agents", {}).get("list", [])
        gw = gw_status()

        # Multi-seat: resolve each agent's bot username
        seats = []
        if len(agents_list) > 1:
            for agent in agents_list:
                seat_id = agent.get("id", "")
                account = telegram.get(seat_id, {})
                token = account.get("botToken", "")
                username = ""
                if token:
                    try:
                        r = test_bot_token(token)
                        username = r.bot_username or ""
                    except Exception:
                        pass
                seats.append({"id": seat_id, "username": username, "token": token})
            return render_template("dashboard.html",
                                    gateway=gw.to_dict(),
                                    seats=seats,
                                    multi_seat=True,
                                    license_seats=cm.get_license_seats(),
                                    version=__version__)
        else:
            # Single-seat
            bot_token = telegram.get("botToken", "")
            bot_username = ""
            if bot_token:
                try:
                    r = test_bot_token(bot_token)
                    bot_username = r.bot_username or ""
                except Exception:
                    pass
            return render_template("dashboard.html",
                                    gateway=gw.to_dict(),
                                    bot_username=bot_username,
                                    seats=[],
                                    multi_seat=False,
                                    license_seats=cm.get_license_seats(),
                                    version=__version__)

    # ------------------------------------------------------------------
    # API endpoints (JSON)
    # ------------------------------------------------------------------

    @app.route("/api/status")
    def api_status():
        status = cm.get_setup_status()
        gw = gw_status()
        return jsonify({
            "setup": status,
            "gateway": gw.to_dict(),
        })

    @app.route("/api/restart", methods=["POST"])
    def api_restart():
        result = gw_restart()
        time.sleep(3)
        gw = gw_status()
        return jsonify({
            "success": not result.error,
            "error": result.error,
            "gateway": gw.to_dict(),
        })

    @app.route("/api/test-provider", methods=["POST"])
    def api_test_provider():
        data = request.get_json(silent=True) or {}
        provider = data.get("provider", "").strip().lower()
        api_key = data.get("api_key", "").strip()
        if provider not in PROVIDER_META:
            return jsonify({"success": False, "error": "Unknown provider."}), 400
        if not api_key:
            return jsonify({"success": False, "error": "API key is required."}), 400
        result = test_provider(provider, api_key)
        return jsonify(result.to_dict())

    @app.route("/api/test-telegram", methods=["POST"])
    def api_test_telegram():
        data = request.get_json(silent=True) or {}
        token = data.get("bot_token", "").strip()
        result = test_bot_token(token)
        return jsonify(result.to_dict())

    @app.route("/api/reset", methods=["POST"])
    def api_reset():
        """Reset to wizard mode (clears setup state including license)."""
        try:
            cm.merge_and_save({
                "channels": {"telegram": {"enabled": False, "botToken": ""}},
                "defaultModel": "",
                "agents": {"list": []},
                "bindings": [],
            })
            env = cm.load_env()
            for meta in PROVIDER_META.values():
                env.pop(meta["env_var"], None)
            env.pop("LICENSE_KEY", None)
            env.pop("LICENSE_SEATS", None)
            cm.save_env(env)
            # Clear license file
            cm._license_path.unlink(missing_ok=True)
            clear_seat_state()
            return jsonify({"success": True})
        except Exception as exc:
            return jsonify({"success": False, "error": str(exc)})

    return app


def main():
    port = int(os.environ.get("WIZARD_PORT", "18792"))
    host = os.environ.get("WIZARD_HOST", "0.0.0.0")
    app = create_app()
    log.info("Starting StrataOS Control Panel on http://%s:%d", host, port)
    app.run(host=host, port=port, debug=False)


if __name__ == "__main__":
    main()
