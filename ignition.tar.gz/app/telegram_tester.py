"""
Telegram Tester — validate bot tokens via the Telegram Bot API.

Uses GET /bot<token>/getMe to confirm the token is valid and the bot exists.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Any

import requests

log = logging.getLogger(__name__)

TELEGRAM_API = "https://api.telegram.org"
REQUEST_TIMEOUT = 10

# Telegram bot tokens look like:  123456789:ABCDEFghijklMNOPQRSTuvwxyz_0123456789
# Length after colon varies — be permissive
TOKEN_PATTERN = re.compile(r"^\d{5,15}:[A-Za-z0-9_-]{20,50}$")


@dataclass
class TelegramTestResult:
    success: bool
    bot_username: str | None = None
    bot_name: str | None = None
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "bot_username": self.bot_username,
            "bot_name": self.bot_name,
            "error": self.error,
        }


def validate_token_format(token: str) -> str | None:
    """Return an error message if the token format looks wrong, else None."""
    token = token.strip()
    if not token:
        return "Bot token is required."
    if not TOKEN_PATTERN.match(token):
        return (
            "That doesn't look like a valid bot token. "
            "It should look like 123456789:ABCdefGHI... "
            "(get one from @BotFather in Telegram)."
        )
    return None


def validate_user_id(user_id: str) -> str | None:
    """Return an error message if the user ID format is wrong, else None."""
    user_id = user_id.strip()
    if not user_id:
        return "Your Telegram user ID is required."
    if not user_id.isdigit():
        return (
            "User ID should be a number. "
            "Send /start to @userinfobot in Telegram to get yours."
        )
    return None


def test_bot_token(token: str) -> TelegramTestResult:
    """Call Telegram's getMe endpoint to validate a bot token."""
    token = token.strip()

    fmt_err = validate_token_format(token)
    if fmt_err:
        return TelegramTestResult(success=False, error=fmt_err)

    try:
        resp = requests.get(
            f"{TELEGRAM_API}/bot{token}/getMe",
            timeout=REQUEST_TIMEOUT,
        )
    except requests.Timeout:
        return TelegramTestResult(
            success=False,
            error="Connection to Telegram timed out. Please try again.",
        )
    except requests.ConnectionError:
        return TelegramTestResult(
            success=False,
            error="Could not reach Telegram. Check your internet connection.",
        )

    if resp.status_code == 401:
        return TelegramTestResult(
            success=False,
            error="Invalid bot token. Please double-check the token from @BotFather.",
        )

    if resp.status_code != 200:
        return TelegramTestResult(
            success=False,
            error=f"Telegram returned an unexpected response (HTTP {resp.status_code}).",
        )

    try:
        data = resp.json()
    except ValueError:
        return TelegramTestResult(
            success=False,
            error="Received an invalid response from Telegram.",
        )

    if not data.get("ok"):
        return TelegramTestResult(
            success=False,
            error=data.get("description", "Unknown Telegram error."),
        )

    result = data.get("result", {})
    return TelegramTestResult(
        success=True,
        bot_username=result.get("username"),
        bot_name=result.get("first_name"),
    )


def build_telegram_config(token: str, user_id: str) -> dict:
    """Build the channels.telegram config block for openclaw.json.
    
    Note: OpenClaw's schema for channels.telegram only allows
    'enabled' and 'botToken'. Authorization (allowFrom) is handled
    separately via device pairing, not in the channel config.
    The user_id is kept for future use but not written to config.
    """
    return {
        "channels": {
            "telegram": {
                "enabled": True,
                "botToken": token.strip(),
            }
        }
    }
