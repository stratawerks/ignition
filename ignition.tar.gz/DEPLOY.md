# Deploy Setup Wizard to Beta Unit

## Prerequisites
- Access to beta unit web terminal: http://192.168.1.235:18790
- Login as `oliver` (password: `oliver`)

## Step 1: Transfer files

From Hal's VM, create a temporary web server to serve the tarball:

```bash
# On Hal's VM (run this first)
cd /tmp && python3 -m http.server 9999 &
```

Then on the beta unit web terminal:

```bash
# On beta unit
cd /tmp
curl -O http://10.0.10.1:9999/setup-wizard.tar.gz  # If VM can reach Hal
# OR if on same LAN:
curl -O http://<hal-ip>:9999/setup-wizard.tar.gz
```

## Step 2: Install on beta unit

```bash
# Create directory
mkdir -p /home/oliver/setup-wizard
cd /home/oliver/setup-wizard

# Extract
tar xzf /tmp/setup-wizard.tar.gz

# Install Python dependencies
pip3 install flask requests

# Test it runs
python3 -c "from app.main import create_app; print('OK')"
```

## Step 3: Run the wizard

```bash
cd /home/oliver/setup-wizard
python3 -m app.main
```

Opens on https://0.0.0.0:8443

## Step 4: Access from browser

Open: https://192.168.1.235:8443/setup

Accept the self-signed certificate warning.

## Notes
- The wizard writes to ~/.openclaw/openclaw.json
- It never runs `openclaw onboard`
- It auto-generates a self-signed HTTPS cert on first run
- Gateway restart handled automatically after config changes
